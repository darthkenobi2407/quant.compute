# quant.compute

An open-source FPGA-based computing platform with custom hardware accelerators.

## Project status

Initial project workspace. Hardware architecture and component choices are not yet finalized.
